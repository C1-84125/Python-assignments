num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))
num3 = int(input("Enter the third number: "))

average = (num1 + num2 + num3) / 3

print(f"The average of the three numbers is: {average}")
